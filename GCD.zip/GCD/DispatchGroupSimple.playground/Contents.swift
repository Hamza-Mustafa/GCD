import UIKit

//https://developer.apple.com/documentation/dispatch/dispatchqueue/2300020-asyncafter

// Dispatch Group Example

func say(_ text: String, completion: @escaping () -> Void) {
    let delay = Double.random(in: 1...2)
    
    // The time at which to schedule the work item for execution. Specifying the current time is less efficient than calling the async(execute:) method directly. Do not specify the value in distantFuture; doing so is undefined.
    // delay time should be random as per apple guidlines to work it as async
    // if  we specify time in delay it will behave sync in serial batch.
    // In our scenario we want to memic sync so we should specify time in delay to first run login api than parallel api's in series
    
    DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
        print(text)
        completion()
    }
}

let group = DispatchGroup()
print("Login Done")

group.enter()
say("First Crucial Api") {
    group.leave()
}


// parallel api's running async
group.enter()
say("Parallel api # 1") {
    group.leave()
}
group.enter()
say("Parallel api # 2") {
    group.leave()
}
group.enter()
say("Parallel api # 3") {
    group.leave()
}

group.notify(queue: .main) {
    print("Goodbye")
}
