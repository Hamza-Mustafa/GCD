import UIKit

class Service {
    private var pendingWorkItem: DispatchWorkItem?
    let queue = DispatchQueue(label: "Some serial queue")

    func doSomething() {
        pendingWorkItem?.cancel()
        
        let newWorkItem = DispatchWorkItem {
            print("DispatchWorkItem")
        }
        pendingWorkItem = newWorkItem
        
        queue.async(execute: newWorkItem)
    }
}


var obj = Service()
obj.doSomething()
