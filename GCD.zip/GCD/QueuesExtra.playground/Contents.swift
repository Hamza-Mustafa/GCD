import UIKit

// --------------------------------------------------------------------

// Ideal simple practice
let concurrentQueue = DispatchQueue(label: "swiftlee.concurrent.queue", attributes: .concurrent)

concurrentQueue.async {
    // Perform the data request and JSON decoding on the background queue.
    fetchData()

    DispatchQueue.main.async {
        /// Access and reload the UI back on the main queue.
        //tableView.reloadData()
        print("UI Updates Goes Here in Final")
    }
    
    avoidExcessiveThread()
}

func fetchData() {
    print("API Call Code Goes Here")
}

//  output :
//  API Call Code Goes Here
//  UI Updates Goes Here in Final


// --------------------------------------------------------------------

// Avoiding excessive thread creation
/// There are two common scenarios
// 1- Too many blocking tasks are added to concurrent queues forcing the system to create additional threads until the system runs out of threads for your app
// 2- Too many private concurrent dispatch queues exist that all consume thread resources.

// How to prevent excessive thread creation?
// It’s best practice to make use of the global concurrent dispatch queues. This prevents you from creating too many private concurrent queues.

func avoidExcessiveThread(){
    DispatchQueue.global().async {
        /// This global concurrent queue is also known as the background queue and used next to the DispatchQueue.main
        print("global queue")
    }

    DispatchQueue.main.async {
        print("main private queue")
    }
}

//  output :
//  global queue
//  main private queue
