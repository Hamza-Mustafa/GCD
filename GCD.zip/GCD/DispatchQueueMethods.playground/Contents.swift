import UIKit

DispatchQueue.main.async {
    foo(msg: "DispatchQueue.main.async")
}

DispatchQueue.global(qos: .userInitiated).async {
    foo(msg: "DispatchQueue.global.userInitiated")
}

DispatchQueue.global(qos: .userInteractive).async {
    foo(msg: "DispatchQueue.global.userInteractive")
}

DispatchQueue.global(qos: .utility).async {
    foo(msg: "DispatchQueue.global.utility")
}

DispatchQueue.global(qos: .background).async {
    foo(msg: "DispatchQueue.global.background")
    
    // fetch data from api
    DispatchQueue.main.async {
        // Update Ui
        print("update UI")
    }
}

func foo(msg: String){
    print(msg)
}
