import UIKit

//  DispatchQueue is serial queue by defaults

let serialQueue = DispatchQueue(label: "my.serial.queue")

serialQueue.async {
    print("Task1 serial started")
    // Do some work..
    print("Task1 serial finished")
}
serialQueue.async {
    print("Task2 serial started")
    // Do some work..
    print("Task2 serial finished")

}

// A concurrent queue allows us to execute multiple tasks at the same time. Tasks will always start in the order they’re added but they can finish in a different order as they can be executed in parallel.

// Tasks will run on distinct threads that are managed by the dispatch queue.

let concurrentQueue = DispatchQueue(label: "my.concurrent.queue", qos: .default, attributes: .concurrent)

concurrentQueue.async {
    print("Task1 concurrent started")
        // Do some work..
    print("Task1 concurrent finished")
}
concurrentQueue.async {
    print("Task2 concurrent started")
    // Do some work..
    print("Task2 concurrent finished")
}

// Output
//Task1 serial started
//Task1 serial finished
//Task2 serial started
//Task2 serial finished

//Task1 concurrent started
//Task2 concurrent started
//Task1 concurrent finished
//Task2 concurrent finished

// As you can see, the second task already starts before the first task is finished. This means that both tasks have run in parallel.
